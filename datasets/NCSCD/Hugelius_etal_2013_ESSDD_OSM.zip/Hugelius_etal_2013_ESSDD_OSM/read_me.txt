Metadata description for online supplementary material to the manuscript: Hugelius et al.,: A new dataset for estimating soil organic carbon storage down to 3 m depth in the northern circumpolar permafrost region, ESSDD, 6, 73-93

The online supplemental material is the intellectual property of the authors and is protected under the Creative Commons Attribution (3.0) license  
For more in depth details we refer to the full manuscript. 
If you have any question concerning the data contact: Gustaf Hugelius, Department of Physical Geography and Quaternary Geology, Stockholm University,  SE-106 91 Stockholm, Sweden. Email: gustaf.hugelius@natgeo.su.se

Data description
Date created: 2013-03-04
Next update: none planned  

The online supplementary material consists of a spreadsheet database (1) and an ArcGIS shape file-set (2) which are described below: 
1. A spreadsheet database (file name: Hugelius_et_al_ESSDD_OSM_pedon_database) available as a tab delimited text file or an excel spreadsheet. The excel spreadsheet contains a separate second tab that contains different calculated values for separate pedon groups and geographic regions (includes formulas). Please see the manuscript for more details on geographic and thematic subdivision of pedons. 

The spreadsheet contains one row for each pedon. The information contained in the individual columns is described below. An empty post signifies that no data is available.

Pedon_Id_nr: Unique row number for each pedon (created for this specific compilation) 
Citation: The original citation (if published) or contributing researcher(s) with affiliation (if previously unpublished).
Profile_ID: A unique pedon ID, typically assigned by the researchers that first collected/compiled the data.
NCSCD_region: The region within the Northern Circumpolar Soil Carbon Database in which the pedon is located
Soil_Order: The pedon soil order classification following the USDA Soil Taxonomy
Suborder: The pedon sub-order classification following the USDA Soil Taxonomy
Great_Group: The pedon great group classification following the USDA Soil Taxonomy
Veg_Class: The vegetation at the sampling site. Information does not follow any established classification protocol.
Lat: Site latitude, in decimal degrees north (datum: WGS84)
Long: Site longitude, in decimal degrees east (datum: WGS84)
Basal_Depth: The depth (in cm) to which the soil was sampled in the field and to which there is analyzed data describing C content.
Thaw depth when sampling: In permafrost soils, the thaw depth (in cm) at the time of sampling. Please note that this may not correspond to the active layer depth
SOCC 0-30 cm (kg C m-2): Storage of soil organic carbon in the 0-30 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC 0-100 cm (kg C m-2): Storage of soil organic carbon in the 0-100 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC 100-200 cm (kg C m-2): Storage of soil organic carbon in the 100-200 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC 200-300 cm (kg C m-2): Storage of soil organic carbon in the 200-300 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
Geomorphological setting: A general description of the geomorphological setting/landscape in which the pedon is located. Information does not follow any established classification protocol.

Sample_date: Date on which the pedon was sampled, YYYY-MM-DD. In many cases only YYYY or YYYY-MM is available.


2. An ArcGIS shape file-set with vector point locations of all pedons included in the database.

The file is in the geographic coordinate system WGS84.

For each point location the following fields are included in the point attribute table:

PEDON_ID_N: Unique row number for each pedon (created for this specific compilation) 
PROFILE_ID: A unique pedon ID, typically assigned by the researchers that first collected/compiled the data.
NCSCD_REGI: The region within the Northern Circumpolar Soil Carbon Database in which the pedon is located
SOIL_ORDER: The pedon soil order classification following the USDA Soil Taxonomy
SUBORDER: The pedon sub-order classification following the USDA Soil Taxonomy
GREAT_GROU: The pedon great group classification following the USDA Soil Taxonomy
LAT: Site latitude, in decimal degrees north (datum: WGS84)
LONG_: Site longitude, in decimal degrees east (datum: WGS84)
BASAL_DEPT: The depth (in cm) to which the soil was sampled in the field and to which there is analyzed data describing C content.
THAW_DEPTH: In permafrost soils, the thaw depth (in cm) at the time of sampling. Please note that this may not correspond to the active layer depth
SOCC_30CM: Storage of soil organic carbon in the 0-30 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC_100CM: Storage of soil organic carbon in the 0-100 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC_200_C: Storage of soil organic carbon in the 100-200 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).
SOCC_300CM: Storage of soil organic carbon in the 200-300 cm depth range (kg C m-2). The zero reference depth is at the upper part of the O-horizon (litter layer excluded).

